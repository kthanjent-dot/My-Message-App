/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registrationapplication;
import java.util.Scanner;
/**
 *
 * @author Student
 */
public class RegistrationApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println("=== USER REGISTRATION ===");
        boolean registeredSuccessfully = false;

        // Keep prompting until the user registers successfully.
        while (!registeredSuccessfully) {
            System.out.print("Enter first name: ");
            String firstName = scanner.nextLine();

            System.out.print("Enter last name: ");
            String lastName = scanner.nextLine();

            System.out.print("Enter username (must contain '_' and be <= 5 characters): ");
            String username = scanner.nextLine();

            System.out.print("Enter password (8+ chars, capital, number, special char): ");
            String password = scanner.nextLine();

            System.out.print("Enter South African cell number (e.g. +27838968976): ");
            String cellphoneNumber = scanner.nextLine();

            String result = login.registerUser(firstName, lastName, username, password, cellphoneNumber);
            System.out.println();
            System.out.println(result);
            System.out.println();

            registeredSuccessfully = login.isRegistered();

            if (!registeredSuccessfully) {
                System.out.println("Please try again.\n");
            }
        }

        System.out.println("=== LOGIN ===");
        System.out.print("Enter username: ");
        String loginUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = scanner.nextLine();

        boolean loginSuccessful = login.loginUser(loginUsername, loginPassword);
        System.out.println();
        System.out.println(login.returnLoginStatus(loginSuccessful));

        scanner.close();
    }
}

